// document.write("its run")

// studet=34

// document.write(studet)

age=prompt("enter your age")
// age=18
// document.write(age)

if(age>=18){
    // document.write("Eligible for vote")
alert("eligible for vote")
}
else{
    document.write("you are not eligible for vote")
}